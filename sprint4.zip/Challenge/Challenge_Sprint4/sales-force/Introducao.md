Neste projeto abordamos o site da Sales Force, na qual desenvolvemos em grupo.

Nomes: Igor Mendes Oviedo, Matheus Rodrigo e Beatriz Silva.

Rm: 553434, 552600, 553180.

Neste projeto, usamos REACT e TYPESCRPIT

O projeto possui o total de 6 paginas.

Abordando o conteudo do figma.

A Ide usada foi o VScode, na qual foi baseado pelo projeto do figma com a ajuda de todos os participantes do grupo.