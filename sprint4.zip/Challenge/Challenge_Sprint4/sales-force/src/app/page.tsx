import Image from "next/image";
import styles from "./page.module.css";
import Header from "./Header/page";
import Footer from "./Footer/page";
import Inicial from "./Inicial/page";



export default function Home() {
  return (
    <Inicial/>
  );
}
